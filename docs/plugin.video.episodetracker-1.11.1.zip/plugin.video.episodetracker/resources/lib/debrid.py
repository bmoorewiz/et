# -*- coding: utf-8 -*-
"""Debrid dispatcher.

Real-Debrid and TorBox expose the same contract, so everything above this
layer stays provider-agnostic. Both can be enabled at once: sources are
tried against each in the configured order, which is worth doing because a
torrent uncached on one is often cached on the other.
"""

from resources.lib import control
from resources.lib import health
from resources.lib import realdebrid
from resources.lib import torbox

# label -> module
_MODULES = {'Real-Debrid': realdebrid, 'TorBox': torbox}
# short tags used in source labels
TAGS = {'Real-Debrid': 'RD', 'TorBox': 'TB'}


def _rd_enabled():
	# Real-Debrid has no explicit toggle: having a token is the switch, so
	# existing installs keep working untouched.
	return realdebrid.authorized()


def providers():
	"""Enabled providers, in the configured priority order."""
	active = []
	if _rd_enabled():
		active.append('Real-Debrid')
	if torbox.enabled():
		active.append('TorBox')
	# 0 = Real-Debrid first (default), 1 = TorBox first
	if control.get_int('debrid.priority', 0) == 1:
		active.reverse()
	return active


def module(name):
	return _MODULES[name]


def any_authorized():
	return bool(providers())


def account_status():
	"""``(ok, message)`` - ok when at least one enabled provider is usable."""
	names = providers()
	if not names:
		return False, ('No debrid provider is set up. Authorize Real-Debrid '
					   'or add a TorBox API key under Settings > Accounts.')
	messages, healthy = [], False
	for name in names:
		try:
			ok, message = _MODULES[name].account_status()
		except Exception:
			control.error('%s account check failed' % name)
			ok, message = False, 'could not be checked'
		healthy |= ok
		messages.append('%s: %s' % (name, message))
	return healthy, ' | '.join(messages)


def cached_hashes(hashes):
	"""Which provider has each hash cached.

	Returns ``(mapping, usable)`` where mapping is hash -> list of provider
	names. ``usable`` is True when at least one provider actually answered.
	"""
	mapping, usable = {}, False
	for name in providers():
		try:
			cached, provider_usable = _MODULES[name].cached_hashes(list(hashes))
		except Exception:
			control.error('%s cache check failed' % name)
			continue
		# Per provider, so a log answers "why is it never using X" directly
		# rather than only saying nobody had anything to say.
		control.log('%s cache check: %s'
					% (name, '%d of %d cached' % (len(cached), len(hashes))
					   if provider_usable else 'no usable answer'))
		usable |= bool(provider_usable)
		for info_hash in cached:
			mapping.setdefault(info_hash, []).append(name)
	return mapping, usable


def order_for(source_cached_by):
	"""Enabled providers, with the ones holding this source cached first.

	The source list already knows who has a given torrent - that is what the
	[RD+]/[TB+] flags mean - so starting with anyone else contradicts what
	the user just picked, and spends the attempt on a provider that would
	have to download the torrent from scratch. Providers that reported no
	cache information still get their turn, just afterwards.
	"""
	names = providers()
	if source_cached_by:
		holders = [n for n in names if n in source_cached_by]
		names = holders + [n for n in names if n not in holders]
	# A provider that has stopped answering goes last whatever the order.
	# It still gets its turn - the request layer returns immediately while
	# it is benched, so this costs nothing - but the one that can actually
	# serve the stream is asked first.
	return sorted(names, key=lambda name: health.benched(name))


def serviceable(name):
	"""Can this provider actually serve a stream right now?

	An expired subscription, a free plan or a rejected key all mean no.
	The answer is cached for an hour by each provider's own account check,
	so asking per source costs nothing.
	"""
	if health.benched(name):
		return False
	try:
		ok, _message = _MODULES[name].account_status()
	except Exception:
		control.error('%s account check failed' % name)
		return True  # unknown is not the same as no; do not exclude on a guess
	return bool(ok)


def _usable(names):
	"""Split providers into those that can serve now and those that cannot."""
	usable = [name for name in names if serviceable(name)]
	return usable, [name for name in names if name not in usable]


def days_left(name):
	module_ = _MODULES.get(name)
	getter = getattr(module_, 'days_left', None)
	return getter() if getter else None


def expiring_soon(within_days=3):
	"""Providers whose subscription runs out shortly: ``[(name, days)]``."""
	soon = []
	for name in providers():
		days = days_left(name)
		if days is not None and 0 < days <= within_days:
			soon.append((name, days))
	return soon


def resolve_magnet(magnet, info_hash, season=None, episode=None, title='',
				   cached_by=None):
	"""Try each enabled provider, whoever has it cached first.

	Returns ``(url, error, provider)``. The provider name is carried back
	rather than only logged, so the caller can tell the user which service
	is actually serving the stream when both are enabled.
	"""
	names = order_for(cached_by)
	if not names:
		return None, 'No debrid provider is set up.', None

	# Leave out anything that cannot serve right now - a lapsed
	# subscription is the common one - so the other provider simply takes
	# over instead of every source failing through the dead one first.
	# Only while something else is left: with one provider its real error
	# is far more use than silence.
	usable, unusable = _usable(names)
	if usable and unusable:
		control.log('skipping %s (cannot serve right now); using %s'
					% (', '.join(unusable), ', '.join(usable)))
		names = usable

	errors = []
	for name in names:
		try:
			url, error = _MODULES[name].resolve_magnet(
				magnet, info_hash, season, episode, title)
		except Exception as exc:
			control.error('%s resolve failed' % name)
			url, error = None, 'unexpected error: %s' % exc
		if url:
			control.log('resolved via %s' % name)
			return url, None, name
		errors.append('%s: %s' % (name, error))
	return None, ' | '.join(errors), None
